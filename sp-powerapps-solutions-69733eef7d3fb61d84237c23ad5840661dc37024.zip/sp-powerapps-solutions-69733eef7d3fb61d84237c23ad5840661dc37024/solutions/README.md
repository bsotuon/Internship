# SharePoint PowerApps Solution samples

Each specific solution is located on dedicated sub folder. Each solution has independent instructions on how to get started with them. 